#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="${1:-$HOME/swarmdock_ver0.2_runtime}"

echo "[SwarmDock] install target: $INSTALL_DIR"

mkdir -p "$INSTALL_DIR"

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cp -a "$BASE_DIR/bin" "$INSTALL_DIR/"
cp -a "$BASE_DIR/bootstrap" "$INSTALL_DIR/"
cp -a "$BASE_DIR/env" "$INSTALL_DIR/"
cp -a "$BASE_DIR/doc" "$INSTALL_DIR/" 2>/dev/null || true

chmod +x "$INSTALL_DIR/bin/swarmdock"
chmod +x "$INSTALL_DIR/bootstrap/swarmdock_start.sh"
chmod +x "$INSTALL_DIR/bootstrap/scan_ros_masters"

if [[ ! -f "$INSTALL_DIR/env/device.conf" ]]; then
  cp "$INSTALL_DIR/env/device.conf.example" "$INSTALL_DIR/env/device.conf"
  echo "[SwarmDock] created default env/device.conf"
fi

echo
echo "[OK] SwarmDock installed."
echo
echo "Add this to ~/.bashrc:"
echo "  export PATH=\"$INSTALL_DIR/bin:\$PATH\""
echo
echo "Then run:"
echo "  source ~/.bashrc"
echo "  vim $INSTALL_DIR/env/device.conf"
echo "  swarmdock host info"
echo "  swarmdock --auto topics --canon"
